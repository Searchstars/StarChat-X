﻿using MongoDB.Bson;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StarChatServer
{
    internal class BSON_Simple
    {
        /*
        var doc = new[]
            {
                new BsonDocument{
                    { "DepartmentName","开发部"},
                    { "People",new  BsonArray
                        {
                            new BsonDocument{ { "Name", "狗娃" },{"Age",20 } },
                             new BsonDocument{ { "Name", "狗剩" },{"Age",22 } },
                              new BsonDocument{ { "Name", "铁蛋" },{"Age",24 } }
                        }
                    },
                    {"Sum",18 },
                      { "dim_cm", new BsonArray { 14, 21 } }


                },
                 new BsonDocument{
                    { "DepartmentName","测试部"},
                    { "People",new  BsonArray
                        {
                            new BsonDocument{ { "Name", "张三" },{"Age",11 } },
                             new BsonDocument{ { "Name", "李四" },{"Age",34 } },
                              new BsonDocument{ { "Name", "王五" },{"Age",33 } }
                        }
                    }
                     ,
                     { "Sum",4 }
                     ,
                       { "dim_cm", new BsonArray { 14, 21 } }

                },
                  new BsonDocument{
                    { "DepartmentName","运维部"},
                    { "People",new  BsonArray
                        {
                            new BsonDocument{ { "Name", "闫" },{"Age",20 } },
                             new BsonDocument{ { "Name", "王" },{"Age",22 } },
                              new BsonDocument{ { "Name", "赵" },{"Age",24 } }
                        }
                    },
                     { "Sum",2 },
                       { "dim_cm", new BsonArray { 22.85, 30 } }

                }
            };
        */
    }
}
